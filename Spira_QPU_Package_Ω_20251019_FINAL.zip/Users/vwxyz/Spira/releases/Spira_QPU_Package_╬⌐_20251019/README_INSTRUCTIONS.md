Spira QPU Simulation & Integration Package (Global-Ready)
--------------------------------------------------------
Encoding: UTF-8 | Time: ISO 8601 UTC | Units: SI | Hash: SHA-512

Files included:
- simulate_q_test.py            : Local quantum simulator (Qiskit template).
- qpu_integration_manifest.json : Vendor integration manifest.
- qpu_job_verifier.py           : Script for verifying simulation vs QPU output.
- QPU_ACTIVATION_CHECKLIST.txt  : Manual approval checklist.

Quick start (local simulation):
1) Create venv: python3 -m venv ~/spira_qenv
2) Activate: source ~/spira_qenv/bin/activate
3) Install (optional): pip install qiskit qiskit-aer
4) Run simulation: python simulate_q_test.py > sim_report.json
5) Verify (if you have qpu_report.json): python qpu_job_verifier.py sim_report.json qpu_report.json
6) Archive: mv sim_report.json ~/Spira/reports/

Security:
- Never enable real QPU access without manual 3-signature authorization.
- All output must include SHA-512 hash for audit.
- All timestamps must be UTC ISO-8601.

Compliance:
- Encoding: UTF-8 (ISO/IEC 10646)
- Datetime: ISO 8601 (UTC)
- Hash: SHA-512
- Units: SI

