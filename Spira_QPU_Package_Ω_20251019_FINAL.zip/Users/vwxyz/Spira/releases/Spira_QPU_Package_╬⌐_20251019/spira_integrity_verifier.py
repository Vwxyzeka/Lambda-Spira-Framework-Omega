#!/usr/bin/env python3
# Λ-Spira Integrity Verifier vΩ.1
# Full end-to-end reproducibility check
# UTF-8 | UTC | SHA-512 | GPG-Verified
import os, json, hashlib, subprocess, time, sys

ROOT = os.path.expanduser("~/Spira/simulation/Spira_QPU_package")
os.chdir(ROOT)
timestamp = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

def sha512(path):
    with open(path, "rb") as f:
        return hashlib.sha512(f.read()).hexdigest()

def load_json(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def check_registry():
    print("🧾 Checking registry_hash_index.json ...")
    reg = load_json("registry_hash_index.json")
    reg_map = {r["file"]: r["sha512"] for r in reg}
    mismatches = []
    for f in sorted(os.listdir(".")):
        if os.path.isfile(f) and f in reg_map:
            actual = sha512(f)
            if reg_map[f] != actual:
                mismatches.append((f, reg_map[f], actual))
    if mismatches:
        print("❌ Registry mismatches found:")
        for f, old, new in mismatches:
            print(f"  - {f}\n    expected: {old}\n    actual:   {new}")
        return False
    print("✅ registry_hash_index.json integrity OK")
    return True

def verify_archive_and_sig():
    base = os.path.expanduser("~/Spira/simulation")
    zips = [f for f in os.listdir(base) if f.startswith("Spira_QPU_Package_Final_") and f.endswith(".zip")]
    if not zips:
        print("⚠️ No final ZIP package found under ~/Spira/simulation/")
        return False
    target = os.path.join(base, sorted(zips)[-1])
    sig = target + ".sig"
    print(f"🗜️ Checking archive: {os.path.basename(target)}")
    h = sha512(target)
    print(f"   SHA-512: {h}")
    if not os.path.exists(sig):
        print("⚠️ Signature file not found:", sig)
        return False
    print("🔐 Verifying GPG signature...")
    res = subprocess.run(["gpg", "--verify", sig, target], capture_output=True, text=True)
    if "Good signature" in res.stderr:
        print("✅ GPG signature OK")
        return True
    print("❌ Signature verification failed.")
    print(res.stderr)
    return False

def generate_manifest():
    print("📘 Generating manifest_release.json ...")
    files = []
    for root, _, fs in os.walk("."):
        for f in sorted(fs):
            path = os.path.join(root, f)
            with open(path, "rb") as fh:
                b = fh.read()
            files.append({
                "path": path.lstrip("./"),
                "size": len(b),
                "sha512": hashlib.sha512(b).hexdigest()
            })
    json.dump(files, open("manifest_release.json", "w"), indent=2, ensure_ascii=False)
    subprocess.run(["gpg", "--output", "manifest_release.json.sig", "--detach-sig", "manifest_release.json"])
    print("✅ manifest_release.json + .sig generated.")
    return True

def final_summary():
    print("\n───────────────────────────────")
    print("Λ-Spira Integrity Verification Summary")
    print("───────────────────────────────")
    print("Timestamp (UTC):", timestamp)
    ok = True
    ok &= check_registry()
    ok &= verify_archive_and_sig()
    ok &= generate_manifest()
    print("───────────────────────────────")
    if ok:
        print("🎯 ALL CHECKS PASSED — FULL INTEGRITY CONFIRMED")
    else:
        print("⚠️ One or more integrity checks FAILED.")
    print("───────────────────────────────")

if __name__ == "__main__":
    final_summary()
