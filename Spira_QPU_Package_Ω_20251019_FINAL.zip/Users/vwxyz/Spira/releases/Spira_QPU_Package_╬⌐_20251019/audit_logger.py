import hashlib, json, os, time

def log_event(event_type, payload):
    log = {
        "event_type": event_type,
        "payload": payload,
        "timestamp_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "hash": hashlib.sha512(json.dumps(payload, sort_keys=True).encode()).hexdigest()
    }
    os.makedirs("logs", exist_ok=True)
    fname = f"logs/audit_{int(time.time())}.json"
    with open(fname, "w", encoding="utf-8") as f:
        json.dump(log, f, indent=2, ensure_ascii=False)
    print(f"[LOGGED] {event_type} -> {fname}")
