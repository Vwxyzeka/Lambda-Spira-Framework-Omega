# qpu_job_verifier.py
# Verifies a QPU job report JSON by cross-checking with simulator run (optional)
import json, hashlib, sys, time

def load_report(path):
    with open(path,'rb') as f:
        data = f.read()
    return json.loads(data.decode('utf-8')), hashlib.sha512(data).hexdigest()

def compare_counts(sim_counts, qpu_counts, tolerance=0.05):
    sim_total = sum(sim_counts.values())
    qpu_total = sum(qpu_counts.values())
    if sim_total == 0 or qpu_total == 0:
        return False, "zero total counts"
    sim_p = {k: v/sim_total for k, v in sim_counts.items()}
    qpu_p = {k: v/qpu_total for k, v in qpu_counts.items()}
    keys = set(sim_p.keys()) | set(qpu_p.keys())
    l1 = sum(abs(sim_p.get(k,0) - qpu_p.get(k,0)) for k in keys)
    return (l1 <= tolerance), {"l1_distance": l1, "tolerance": tolerance}

if __name__ == '__main__':
    if len(sys.argv) < 3:
        print("Usage: python qpu_job_verifier.py <sim_report.json> <qpu_report.json>")
        sys.exit(1)
    sim_report, sim_hash = load_report(sys.argv[1])
    qpu_report, qpu_hash = load_report(sys.argv[2])
    ok, info = compare_counts(sim_report.get('counts', {}), qpu_report.get('counts', {}))
    out = {
        "sim_hash": sim_hash,
        "qpu_hash": qpu_hash,
        "comparison_ok": ok,
        "info": info,
        "timestamp_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    }
    print(json.dumps(out, indent=2, ensure_ascii=False))

